# -*- coding: utf-8 -*-
#############
#blog的启动程序，调用各个模板，定义文件路径
#
#定义监听端口
#############
import sys
import os

import tornado.web
import tornado.ioloop
import tornado.httpserver
from tornado.options import define, options
import torndb

from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker

from urls import urls

import sys
sys.path.append("Blog_Path") #Blog的根目录地址

define("port", default=8080, help="PORT", type=int)


class Application(tornado.web.Application):
    def __init__(self):
        #路由设置
        handlers = urls

        #配置信息
        settings = dict(
            template_path=os.path.join(os.path.dirname(__file__), "templates"),#前端代码目录
            static_path=os.path.join(os.path.dirname(__file__), "static"),#渲染目录
            # 防跨站伪造请求
            xsrf_cookies=True,
            cookie_secret="c2fc16cbc0e8462248d26b7d74e0b562=",#Cookie的加盐
            login_url="/login",
            debug=False,                  #调试模式
        )
        #服务器初始化
        tornado.web.Application.__init__(self, handlers=urls, **settings)


def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()


if __name__ == "__main__":
    main()


