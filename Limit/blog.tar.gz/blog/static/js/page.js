
function  minmypage(numb){
    var trCount = numb ;//总行数   
    var pageSize = 10; //每页显示条数
    var pageIndex = 1; //当前页数
    var pageCount = 0; //总页数
    var startnumb = 0 ;//展现开始id
    var endnumb = 0 ; //展现结束id 
    var insteall = new Array();//将行数据以数组的形式存储
 
 
 
    /**获取所有行数据 将行数据以数组形式存储*/
    function savePage(){
 
        var str = $("#mytbody").html();//id='mytbody'属性赋给<tr>的父标签
        var strs = new Array();
        strs = str.split("</tr>");
        for(var i = 0 ; i <= endnumb-startnumb ; i++){
            var index = startnumb + i ;
            insteall[index] = strs[i] + "</tr>" ;
        }
    }
 
    /**展现开始id 展现结束id */
    function countPage(){
        startnumb = (pageIndex -1) * pageSize ;
        if((pageIndex* pageSize) > (insteall.length) ){
            endnumb = insteall.length -1;
        }else{
            endnumb = pageIndex* pageSize -1
        }
 
    }
    //初始化 基本参数
     this.init = function(){    
        var str = $("#mytbody").html();
        insteall = str.split("</tr>");
        pageCount = Math.ceil(trCount / pageSize) ;//总页数
        countPage();
 
    }
    /**外部调用展现函数*/
    this.show = function() {
        var html = "";
        for(var i = startnumb ; i < endnumb + 1 ; i++){
            html += insteall[i] + "</tr>" ;
        }
        $("#mytbody").html(html);
 
 
    }
    /**下一页函数*/ 
    this.next = function() {
        if(pageIndex >= pageCount){
            return ;
        }
        savePage(); //将页面数据保存到数组
        pageIndex++;//当前页加一
        countPage();//给展现开始id 展现结束id 赋值 
        this.show();    
    }
    /**上一页*/   
    this.pageUp = function() {
        if(pageIndex <= 1 ){
            return ;
        }
        savePage(); //将页面数据保存到数组
        pageIndex--;//当前页加一
        countPage();//给展现开始id 展现结束id 赋值 
        this.show();
    }
    /**首页*/
    this.pageFirst = function() {
        if(pageIndex == 1 ){
            return ;
        }
        savePage(); //将页面数据保存到数组
        pageIndex = 1;//当前页首页
        countPage();//给展现开始id 展现结束id 赋值 
        this.show();
    }
 
    /**尾页*/
    this.pageEnd = function() {
        if(pageIndex == pageCount ){
            return ;
        }
        savePage(); //将页面数据保存到数组
        pageIndex = pageCount;//当前末页
        countPage();//给展现开始id 展现结束id 赋值 
        this.show();
    }
} ;
 
 

