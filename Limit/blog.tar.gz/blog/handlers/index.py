# -*- coding: utf-8 -*-

from base import BaseHandler
from models.post import Post
import tornado.web
import time

from service import PostService


class MainHandler(BaseHandler):
    def get(self):
        posts = PostService.get_list()#查询出所有的文章,是一个dic
        source = '../static/'
        self.render('index.html',source=source,posts=posts)#展示index.html页面，定义index.html中的POST为上述变量的值
        
    def post(self):
        search = self.get_argument('search')
        source = '../static/'
        posts = PostService.search(search)
        self.render('index.html',source=source,posts=posts)
        
#后台展示功能
class HomeHandler(BaseHandler):
    @tornado.web.authenticated #authenticated装饰器
    def get(self):
        posts = PostService.get_list()
        source = '../static/'
        count = len(posts)
        self.render('home.html',source=source,posts=posts,count=count) #必须在首次get的时候就存在传递
   

#登录功能       
class LoginHandler(BaseHandler):
    def get(self):
        if self.current_user != 'L_AnG@g0dA': #密码部分
            source = '../static/'
            self.render('login.html',result='Please Input Your Key',source=source)
        else:
            self.redirect("home")
            
    def post(self):
        username = 'password' #设置登录密码
        if self.get_argument('username')==username:
            self.set_secure_cookie("PYTHONSESSIONID", self.get_argument("username"),path='/',expires_days=None) #会话时间的cookie,关闭浏览器即删除
            self.redirect("home")
        else:
            source = '../static/'
            self.render('login.html',result='Login Error',source=source)

#登出功能
class LogoutHandler(BaseHandler):
    def get(self):
        if (self.get_argument("logout", "default")):
            self.clear_all_cookies()
            self.redirect("/")

#路由404完成     
class GP404Handler(tornado.web.RequestHandler):
    def get(self):
        self.write_error(404)
    def write_error(self, status_code, **kwargs):
        if status_code == 404:
            source = '../static/'
            self.render('404.html',source = source)
            
#删除文章的Handler
class DelHandler(BaseHandler):
    @tornado.web.authenticated #authenticated装饰器
    def post(self):
        id = self.get_argument("id",None)
        post = PostService.del_article(id)
        self.redirect("home")
        
#edit页面的Handler
class EditHandler(BaseHandler):
    @tornado.web.authenticated #authenticated装饰器
    def post(self):
        id = self.get_argument("id")
        date = PostService.edit_get_article(id)
        source = '../static/'
        self.render('edit.html',source=source,title=date.get('title'),content = date.get('content'),id = date.get('id')) #必须在首次get的时候就存在传递
   

#edit的Update功能
class UpdateHandler(BaseHandler):
    @tornado.web.authenticated #authenticated装饰器
    def post(self):
        id = self.get_argument("id")
        title = self.get_argument("title")
        content = self.get_argument("content")
        post = PostService.edit_update_article(id,title,content)
        self.redirect("home")
        
#文章添加Handler
class AddHandler(BaseHandler):
    @tornado.web.authenticated #authenticated装饰器
    def get(self):
        source = '../static/'
        self.render('add.html',source=source,info1="info",info2="警告",info3="认真写文章啊.")
    
    #文章上传功能
    @tornado.web.authenticated #authenticated装饰器
    def post(self):
        title = self.get_argument("title")
        content = self.get_argument("content")
        date = str(time.strftime('%Y-%m-%d',time.localtime(time.time())))
        if title == '' or content == '':
            source = '../static/'
            self.render('add.html',source=source,info1="error",info2="错误",info3="文章标题或内容不能为空.")
        else:
            post = PostService.add(title, content, date)
        
        if post:
            source = '../static/'
            self.render('add.html',source=source,info1="success",info2="正确",info3="文章上传成功.")

# 友链访问
class LinkHandler(BaseHandler):
    def get(self):
        source = '../static/'
        self.render('link.html',source=source)

#个人资料
class MeHandler(BaseHandler):
    def get(self):
        source = '../static/'
        self.render('me.html',source=source)
