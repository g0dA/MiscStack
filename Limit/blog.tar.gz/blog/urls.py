# -*- coding: utf-8 -*-
#########################
#Blog的路由设置，定向handlers
#
#
#########################
from handlers.index import MainHandler
from handlers.index import LoginHandler, LogoutHandler, HomeHandler,GP404Handler,DelHandler,EditHandler,UpdateHandler,AddHandler,MeHandler,LinkHandler
from base import BaseHandler

urls = [
    (r'/', MainHandler),
    (r'/login', LoginHandler),
    (r'/logout', LogoutHandler),
    (r'/home', HomeHandler),
    (r'/del', DelHandler),
    (r'/edit', EditHandler),
    (r'/update', UpdateHandler),
    (r'/add', AddHandler),
    (r'/me', MeHandler),
    (r'/link', LinkHandler),
    (r".*", GP404Handler),#用于捕获未被其他规则捕获的所有请求

]
