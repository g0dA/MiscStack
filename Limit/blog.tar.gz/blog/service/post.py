# -*- coding: utf-8 -*-

from models import Post
from extensions import db
from sqlalchemy import desc
import markdown

class PostService(object):

    @staticmethod
    def add(title, content, date):
        html = markdown.markdown(content)
        post = Post(title=title, content=content,html=html,date=date)
        db.add(post)#插入数据
        db.commit()#同步清理缓存
        return post.to_dict()

    @staticmethod
    def get_list():
         posts = db.query(Post).order_by(Post.id.desc())#查询数据库
         return [post.to_dict() for post in posts]

    @staticmethod
    def del_article(id):
        query = 'DELETE FROM `post` WHERE `post`.`id` = '+str(int(id))
        db.execute(query)
        db.commit()#同步清理缓存
    
    @staticmethod
    def edit_get_article(id):
        dates = db.query(Post).get(int(id))
        return dates.to_dict()
    
    @staticmethod
    def edit_update_article(id,title,content):
        html = markdown.markdown(content)        
        db.query(Post).filter(Post.id == id).update({Post.content:content})
        db.query(Post).filter(Post.id == id).update({Post.title:title})
        db.query(Post).filter(Post.id == id).update({Post.html:html})
        db.commit()#同步清理缓存

    @staticmethod
    def search(date):
        date = "%"+date+"%"
        dates = db.query(Post).filter(Post.title.like(date)).order_by(Post.id.desc())
        return [date.to_dict() for date in dates]