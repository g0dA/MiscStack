# -*- coding: utf-8 -*-

from post import PostService
